﻿/* B4US Social Proof Notification System */
(function() {
  var products = [
    'Graffiti Denim',
    'S!NNERS TEE',
    'Peacekeeper Nylon Set',
    'Comfortable Crest Hoodie',
    'B4 Venom Collection'
  ];
  var cities = [
    'New York, NY','Los Angeles, CA','Chicago, IL','Houston, TX','Phoenix, AZ','Philadelphia, PA','San Antonio, TX','San Diego, CA','Dallas, TX','San Jose, CA',
    'Austin, TX','Jacksonville, FL','Fort Worth, TX','Columbus, OH','Charlotte, NC','Indianapolis, IN','Seattle, WA','Denver, CO','Washington, DC','Boston, MA',
    'Nashville, TN','Detroit, MI','Portland, OR','Las Vegas, NV','Memphis, TN','Louisville, KY','Baltimore, MD','Milwaukee, WI','Albuquerque, NM','Tucson, AZ',
    'Kansas City, MO','Atlanta, GA','Omaha, NE','Raleigh, NC','Miami, FL','Minneapolis, MN','Tampa, FL','New Orleans, LA','Cleveland, OH',
    'Paris, France','Lyon, France','Marseille, France','Nice, France'
  ];

  function showNotification() {
    var product = products[Math.floor(Math.random() * products.length)];
    var city = cities[Math.floor(Math.random() * cities.length)];
    var existing = document.querySelector('.b4us-social-proof');
    if (existing) existing.remove();

    var div = document.createElement('div');
    div.className = 'b4us-social-proof';
    div.innerHTML = 'A troop in <span class="troop-city">' + city + '</span> just secured <strong>' + product + '</strong>';
    document.body.appendChild(div);

    setTimeout(function() {
      if (div.parentNode) div.remove();
    }, 5000);
  }

  setTimeout(function() {
    showNotification();
    setInterval(showNotification, 45000);
  }, 15000);
})();
